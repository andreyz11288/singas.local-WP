<?php
/*
Template Name: home
*/
?>

<?php get_header(); ?>

               </div> <div class="fixed-container" bis_skin_checked="1" style="transform: translate3d(0px, 0px, 0px); transition-duration: 500ms;">
               <div class="container home" bis_skin_checked="1">
                <div id='section1' class="section section1 pr df fdc section-no-padding active" bis_skin_checked="1"><div class="absolute-c-logo" bis_skin_checked="1"><div data-v-4e6cd574="" class="wrapper" bis_skin_checked="1"><div data-v-4e6cd574="" class="letters-inner" bis_skin_checked="1"><!----></div> <div data-v-4e6cd574="" class="text-block" bis_skin_checked="1"><div data-v-4e6cd574="" class="top-text-wrapper" bis_skin_checked="1"><div data-v-3a0f674e="" data-v-4e6cd574="" class="top-text" bis_skin_checked="1"><div data-v-3a0f674e="" class="mobile-text active-text" bis_skin_checked="1"><div data-v-3a0f674e="" bis_skin_checked="1">
      DIGITAL
    </div></div><div data-v-3a0f674e="" class="mobile-text active-text" bis_skin_checked="1"><div data-v-3a0f674e="" bis_skin_checked="1">
      INNOVATION
    </div></div><div data-v-3a0f674e="" class="mobile-text active-text" bis_skin_checked="1"><div data-v-3a0f674e="" bis_skin_checked="1">
      COMPANY
    </div></div> <div data-v-3a0f674e="" class="slash" bis_skin_checked="1"></div> <div data-v-3a0f674e="" class="text" bis_skin_checked="1"><div data-v-3a0f674e="" class="text-back" bis_skin_checked="1">DIGITAL INNOVATION COMPANY</div> <div data-v-3a0f674e="" class="text-half text--left" bis_skin_checked="1">
      <div data-v-3a0f674e="" class="inner" bis_skin_checked="1">DIGITAL INNOVATION COMPANY</div></div> <div data-v-3a0f674e="" class="text-half text--right" bis_skin_checked="1"><div data-v-3a0f674e="" class="inner" bis_skin_checked="1">DIGITAL INNOVATION COMPANY</div></div></div></div></div> <!----></div></div></div> <div class="absolute-c-logo2" bis_skin_checked="1"><div class="words-animation" bis_skin_checked="1"><div class="caption-holder" bis_skin_checked="1"><h2 class="word" style="opacity: 1;"><span class="letter out">F</span>
      <span class="letter out">O</span>
      <span class="letter out">U</span>
      <span class="letter out">N</span>
      <span class="letter out">D</span>
      <span class="letter out">A</span>
      <span class="letter out">T</span>
      <span class="letter out">I</span>
      <span class="letter out">O</span>
      <span class="letter out">N</span>
      <span class="letter out">A</span>
      <span class="letter out">L</span>
      <span class="letter out">&nbsp;</span>
      <span class="letter out">T</span>
      <span class="letter out">E</span>
      <span class="letter out">C</span>
      <span class="letter out">H</span>
      <span class="letter out">&nbsp;</span>
      <span class="letter out">O</span>
      <span class="letter out">F</span>
      <span class="letter out">&nbsp;</span>
      <span class="letter out">T</span>
      <span class="letter out">O</span>
      <span class="letter out">M</span>
      <span class="letter out">O</span>
      <span class="letter out">R</span>
      <span class="letter out">R</span>
      <span class="letter out">O</span>
      <span class="letter out">W</span>
      <span class="letter out">&nbsp;</span>
      <span class="letter out">D</span>
      <span class="letter out">E</span>
      <span class="letter out">L</span>
      <span class="letter out">I</span>
      <span class="letter out">V</span>
      <span class="letter out">E</span>
      <span class="letter out">R</span>
      <span class="letter out">E</span>
      <span class="letter out">D</span>
      <span class="letter out">&nbsp;</span>
      <span class="letter out">T</span>
      <span class="letter out">O</span>
      <span class="letter out">D</span>
      <span class="letter out">A</span>
      <span class="letter out">Y</span>
    </h2><h2 class="word" style="opacity: 1;"><span class="letter in">T</span>
      <span class="letter in">R</span>
      <span class="letter in">A</span>
      <span class="letter in">N</span>
      <span class="letter in">S</span>
      <span class="letter in">F</span>
      <span class="letter in">O</span>
      <span class="letter in">R</span>
      <span class="letter in">M</span>
      <span class="letter in">I</span>
      <span class="letter in">N</span>
      <span class="letter in">G</span>
      <span class="letter in">&nbsp;</span>
      <span class="letter in">C</span>
      <span class="letter in">U</span>
      <span class="letter in">L</span>
      <span class="letter in">T</span>
      <span class="letter in">U</span>
      <span class="letter in">R</span>
      <span class="letter in">E</span>
      <span class="letter in">&nbsp;</span>
      <span class="letter in">I</span>
      <span class="letter in">N</span>
      <span class="letter in">T</span>
      <span class="letter in">O</span>
      <span class="letter in">&nbsp;</span>
      <span class="letter in">B</span>
      <span class="letter in">U</span>
      <span class="letter in">S</span>
      <span class="letter in">I</span>
      <span class="letter in">N</span>
      <span class="letter in">E</span>
      <span class="letter in">S</span>
      <span class="letter in">S</span>
      <span class="letter in">&nbsp;</span>
      <span class="letter in">S</span>
      <span class="letter in">U</span>
      <span class="letter in">C</span>
      <span class="letter in">C</span>
      <span class="letter in">E</span>
      <span class="letter in">S</span>
      <span class="letter in">S</span>
      <span class="letter in">&nbsp;</span>
      <span class="letter in">N</span>
      <span class="letter in">O</span>
      <span class="letter in">W</span>
    </h2><h2 class="word" style="opacity: 1;"><span class="letter out">R</span>
      <span class="letter out">E</span>
      <span class="letter out">V</span>
      <span class="letter out">O</span>
      <span class="letter out">L</span>
      <span class="letter out">U</span>
      <span class="letter out">T</span>
      <span class="letter out">I</span>
      <span class="letter out">O</span>
      <span class="letter out">N</span>
      <span class="letter out">I</span>
      <span class="letter out">Z</span>
      <span class="letter out">I</span>
      <span class="letter out">N</span>
      <span class="letter out">G</span>
      <span class="letter out">&nbsp;</span>
      <span class="letter out">B</span>
      <span class="letter out">R</span>
      <span class="letter out">A</span>
      <span class="letter out">N</span>
      <span class="letter out">D</span>
      <span class="letter out">S</span>
      <span class="letter out">&nbsp;</span>
      <span class="letter out">W</span>
      <span class="letter out">I</span>
      <span class="letter out">T</span>
      <span class="letter out">H</span>
      <span class="letter out">&nbsp;</span>
      <span class="letter out">D</span>
      <span class="letter out">I</span>
      <span class="letter out">G</span>
      <span class="letter out">I</span>
      <span class="letter out">T</span>
      <span class="letter out">A</span>
      <span class="letter out">L</span>
      <span class="letter out">&nbsp;</span>
      <span class="letter out">I</span>
      <span class="letter out">N</span>
      <span class="letter out">N</span>
      <span class="letter out">O</span>
      <span class="letter out">V</span>
      <span class="letter out">A</span>
      <span class="letter out">T</span>
      <span class="letter out">I</span>
      <span class="letter out">O</span>
      <span class="letter out">N</span>
    </h2></div></div></div> <div class="text-i text-i3" bis_skin_checked="1"><div class="ovh" bis_skin_checked="1"><p class="text-i2">Bringing your most daring digital dreams to life.</p></div></div> 
      <div data-v-56f8bda8="" class="inner inner1" bis_skin_checked="1">
      <img data-v-56f8bda8="" src="<?php bloginfo('template_url'); ?>/assets/img/logos.svg" alt="logo" class="bg-img">
       <div data-v-56f8bda8="" class="numbers-inner" bis_skin_checked="1"><div data-v-56f8bda8="" class="left" bis_skin_checked="1"><span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 5vmin; animation-duration: 4s; animation-delay: 3.5s; left: 30%;">
  1
</span>
<!----><span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 1s; left: 48%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 5s; left: 31%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 1.5s; left: 75%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 0.5s; left: 41%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 3s; left: 83%;">
  1
</span>
<!----><span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 2.5s; left: 59%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 2.5s; left: 87%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 4.5s; left: 37%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 5vmin; animation-duration: 4s; animation-delay: 5s; left: 67%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 1.5s; left: 37%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 5.5s; left: 27%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 5.5s; left: 85%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 6s; left: 34%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 1.5s; left: 2%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 3.5s; left: 38%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 2s; left: 87%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 4s; left: 14%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 2.5s; left: 15%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 5vmin; animation-duration: 4s; animation-delay: 3.5s; left: 58%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 3.5s; left: 51%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 4.5s; left: 53%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 2s; left: 82%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 5vmin; animation-duration: 4s; animation-delay: 3.5s; left: 61%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 6s; left: 70%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 3.5s; left: 28%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 3s; left: 74%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 4s; left: 74%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 5s; left: 70%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 5vmin; animation-duration: 4s; animation-delay: 3s; left: 53%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 0.5s; left: 17%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 3s; left: 99%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 3.5s; left: 22%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 4s; left: 27%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 1.5s; left: 71%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 4.5s; left: 70%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 1.5s; left: 90%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 5s; left: 66%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 5s; left: 41%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 5s; left: 93%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 5s; left: 6%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 5vmin; animation-duration: 4s; animation-delay: 1s; left: 97%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 2s; left: 41%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 2s; left: 49%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 5s; left: 31%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 2.5s; left: 70%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 5vmin; animation-duration: 4s; animation-delay: 4s; left: 57%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 5s; left: 94%;">
  0
</span>
<!----><span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 0.5s; left: 94%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 5s; left: 17%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 6s; left: 59%;">
  0
</span>
<!----><span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 2.5s; left: 98%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 0.5s; left: 75%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 3.5s; left: 86%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 4s; left: 32%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 3s; left: 33%;">
  0
</span>
</div> <div data-v-56f8bda8="" class="center" bis_skin_checked="1"><span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 0.5s; left: 69%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 5.5s; left: 10%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 0.5s; left: 32%;">
  1
</span>
<!----><!----><span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 6s; left: 85%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 5vmin; animation-duration: 4s; animation-delay: 0.5s; left: 37%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 0s; left: 96%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 6s; left: 50%;">
  1
</span>
<!----><span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 5s; left: 58%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 5.5s; left: 35%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 3.5s; left: 57%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 1.5s; left: 9%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 5.5s; left: 73%;">
  1
</span>
<!----><span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 4s; left: 41%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 3.5s; left: 43%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 5.5s; left: 89%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 5.5s; left: 23%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 3.5s; left: 90%;">
  1
</span>
<!----><span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 4s; left: 39%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 1s; left: 4%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 3s; left: 49%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 3s; left: 12%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 3.5s; left: 55%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 0s; left: 56%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 3.5s; left: 72%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 1.5s; left: 71%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 0.5s; left: 44%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 5.5s; left: 20%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 3s; left: 11%;">
  1
</span>
<!----><span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 4.5s; left: 88%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 3s; left: 88%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 5.5s; left: 99%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 5s; left: 1%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 5s; left: 68%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 4.5s; left: 45%;">
  0
</span>
</div> <div data-v-56f8bda8="" class="right" bis_skin_checked="1"><!----><!----><span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 5vmin; animation-duration: 4s; animation-delay: 3.5s; left: 45%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 2.5s; left: 37%;">
  0
</span>
<!----><span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 3s; left: 91%;">
  0
</span>
<!----><span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 5vmin; animation-duration: 4s; animation-delay: 3s; left: 41%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 3.5s; left: 81%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 5vmin; animation-duration: 4s; animation-delay: 0.5s; left: 5%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 0.5s; left: 21%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 5s; left: 84%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 2s; left: 25%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 5vmin; animation-duration: 4s; animation-delay: 1.5s; left: 64%;">
  0
</span>
<!----><span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 6s; left: 87%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 2s; left: 2%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 4s; left: 51%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 4s; left: 2%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 0.5s; left: 54%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 1.5s; left: 91%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 1s; left: 50%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 2s; left: 58%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 0s; left: 5%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 1s; left: 8%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 5.5s; left: 3%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 3.5s; left: 42%;">
  1
</span>
<!----><span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 4s; left: 51%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 1.5s; left: 28%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 5s; left: 9%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 2.5s; left: 18%;">
  0
</span>
<!----><span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 1s; left: 10%;">
  0
</span>
<!----><span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 0.5s; left: 69%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 4.5s; left: 45%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 5s; left: 67%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 5vmin; animation-duration: 4s; animation-delay: 5s; left: 43%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 5vmin; animation-duration: 4s; animation-delay: 1s; left: 76%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 3s; left: 94%;">
  1
</span>
<!----><span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 4s; left: 38%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 5vmin; animation-duration: 4s; animation-delay: 5.5s; left: 85%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3vmin; animation-duration: 4s; animation-delay: 3.5s; left: 72%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 5vmin; animation-duration: 4s; animation-delay: 4.5s; left: 38%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 4s; left: 23%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 1s; left: 77%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 5vmin; animation-duration: 4s; animation-delay: 5.5s; left: 6%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 5.5s; left: 53%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 2.5s; left: 8%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 3.5s; left: 3%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 3.5s; left: 0%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 3s; left: 88%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 5.5s; left: 5%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 3.5vmin; animation-duration: 4s; animation-delay: 1.5s; left: 32%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 5vmin; animation-duration: 4s; animation-delay: 6s; left: 81%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4vmin; animation-duration: 4s; animation-delay: 2s; left: 74%;">
  0
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 4.5vmin; animation-duration: 4s; animation-delay: 3s; left: 38%;">
  1
</span>
<span data-v-4e491db3="" data-v-56f8bda8="" class="anim" style="font-size: 5vmin; animation-duration: 4s; animation-delay: 3.5s; left: 23%;">
  0
</span>
</div></div></div> <div class="mouse-block" bis_skin_checked="1"><div class="mouse" bis_skin_checked="1"><div class="mouse-wheel" bis_skin_checked="1"></div></div></div> <div data-v-3e3229a0="" class="bottom-block" bis_skin_checked="1"><!----> <a data-v-b07ccaac="" data-v-3e3229a0="" href="/contact-us" class="email-btn"><svg data-v-b07ccaac="" xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="8.1138mm" height="8.1138mm" version="1.1" viewBox="0 0 811380 811380" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="shape-rendering: geometricprecision; text-rendering: geometricprecision; fill-rule: evenodd; clip-rule: evenodd;"><g data-v-b07ccaac=""><path data-v-b07ccaac="" fill="currentColor" d="M117700 100070l575990 0c30130,0 57530,12320 77350,32140 19820,19810 32140,47210 32140,77350l0 466270c0,24700 -11100,35480 -31140,35480 -19750,0 -38840,-23280 -61770,-51270 -24240,-29580 -54670,-66710 -65560,-66710l-527010 0c-30130,0 -57530,-12330 -77350,-32140 -19820,-19820 -32140,-47220 -32140,-77350l0 -274280c0,-30140 12320,-57540 32140,-77350 19820,-19820 47220,-32140 77350,-32140zm109710 209610l82290 0 0 82290 -82290 0 0 -82290zm274280 0l82290 0 0 82290 -82290 0 0 -82290zm-137140 0l82290 0 0 82290 -82290 0 0 -82290zm329140 -155190l-575990 0c-15100,0 -28870,6210 -38860,16200 -9990,9990 -16210,23770 -16210,38870l0 274280c0,15090 6220,28870 16210,38860 9990,9990 23760,16200 38860,16200l527010 0c35220,0 73170,44680 104050,82300l0 -411640c0,-15100 -6220,-28880 -16210,-38870 -9990,-9990 -23760,-16200 -38860,-16200z"></path></g></svg></a></div></div>
      <div id='section2' class="section section2 section-template pr df fdc jcsb" bis_skin_checked="1">
      <canvas id="binary-system" class="binary-system"></canvas>
      <div bis_skin_checked="1"><div data-v-80305aa8="" class="view" bis_skin_checked="1"><div data-v-80305aa8="" class="part" bis_skin_checked="1"><div data-v-80305aa8="" class="plane" bis_skin_checked="1"><div data-v-80305aa8="" class="cube" bis_skin_checked="1"><div data-v-80305aa8="" class="face x" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face y" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face z" bis_skin_checked="1"></div></div><div data-v-80305aa8="" class="cube" bis_skin_checked="1"><div data-v-80305aa8="" class="face x" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face y" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face z" bis_skin_checked="1"></div></div><div data-v-80305aa8="" class="cube" bis_skin_checked="1"><div data-v-80305aa8="" class="face x" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face y" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face z" bis_skin_checked="1"></div></div><div data-v-80305aa8="" class="cube" bis_skin_checked="1"><div data-v-80305aa8="" class="face x" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face y" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face z" bis_skin_checked="1"></div></div><div data-v-80305aa8="" class="cube" bis_skin_checked="1"><div data-v-80305aa8="" class="face x" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face y" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face z" bis_skin_checked="1"></div></div><div data-v-80305aa8="" class="cube" bis_skin_checked="1"><div data-v-80305aa8="" class="face x" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face y" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face z" bis_skin_checked="1"></div></div><div data-v-80305aa8="" class="cube" bis_skin_checked="1"><div data-v-80305aa8="" class="face x" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face y" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face z" bis_skin_checked="1"></div></div><div data-v-80305aa8="" class="cube" bis_skin_checked="1"><div data-v-80305aa8="" class="face x" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face y" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face z" bis_skin_checked="1"></div></div> <div data-v-80305aa8="" class="static" bis_skin_checked="1"><div data-v-80305aa8="" class="cube" bis_skin_checked="1"><div data-v-80305aa8="" class="face x" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face y" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face z" bis_skin_checked="1"></div></div> <div data-v-80305aa8="" class="cube" bis_skin_checked="1"><div data-v-80305aa8="" class="face x" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face y" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face z" bis_skin_checked="1"></div></div></div></div></div><div data-v-80305aa8="" class="part" bis_skin_checked="1"><div data-v-80305aa8="" class="plane" bis_skin_checked="1"><div data-v-80305aa8="" class="cube" bis_skin_checked="1"><div data-v-80305aa8="" class="face x" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face y" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face z" bis_skin_checked="1"></div></div><div data-v-80305aa8="" class="cube" bis_skin_checked="1"><div data-v-80305aa8="" class="face x" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face y" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face z" bis_skin_checked="1"></div></div><div data-v-80305aa8="" class="cube" bis_skin_checked="1"><div data-v-80305aa8="" class="face x" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face y" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face z" bis_skin_checked="1"></div></div><div data-v-80305aa8="" class="cube" bis_skin_checked="1"><div data-v-80305aa8="" class="face x" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face y" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face z" bis_skin_checked="1"></div></div><div data-v-80305aa8="" class="cube" bis_skin_checked="1"><div data-v-80305aa8="" class="face x" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face y" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face z" bis_skin_checked="1"></div></div><div data-v-80305aa8="" class="cube" bis_skin_checked="1"><div data-v-80305aa8="" class="face x" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face y" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face z" bis_skin_checked="1"></div></div><div data-v-80305aa8="" class="cube" bis_skin_checked="1"><div data-v-80305aa8="" class="face x" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face y" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face z" bis_skin_checked="1"></div></div><div data-v-80305aa8="" class="cube" bis_skin_checked="1"><div data-v-80305aa8="" class="face x" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face y" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face z" bis_skin_checked="1"></div></div> <div data-v-80305aa8="" class="static" bis_skin_checked="1"><div data-v-80305aa8="" class="cube" bis_skin_checked="1"><div data-v-80305aa8="" class="face x" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face y" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face z" bis_skin_checked="1"></div></div> <div data-v-80305aa8="" class="cube" bis_skin_checked="1"><div data-v-80305aa8="" class="face x" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face y" bis_skin_checked="1"></div> <div data-v-80305aa8="" class="face z" bis_skin_checked="1"></div></div></div></div></div></div></div> <img src="<?php bloginfo('template_url'); ?>/assets/img/map.svg" alt="" class="svg-img"> 
      <img src="<?php bloginfo('template_url'); ?>/assets/img/sing.0b4abdc.svg" alt="logo" class="bg-img"> <div class="scetch scetch-mob" bis_skin_checked="1">
        <div data-v-4e6cd574="" class="wrapper" bis_skin_checked="1"><div data-v-4e6cd574="" class="letters-inner" bis_skin_checked="1"><!----></div>
         <div data-v-4e6cd574="" class="text-block" bis_skin_checked="1"><div data-v-4e6cd574="" class="top-text-wrapper" bis_skin_checked="1">
          <div data-v-3a0f674e="" data-v-4e6cd574="" class="top-text" bis_skin_checked="1"><div data-v-3a0f674e="" class="mobile-text active-text" bis_skin_checked="1">
            <div data-v-3a0f674e="" bis_skin_checked="1">
      WHO WE ARE
    </div></div> <div data-v-3a0f674e="" class="slash" bis_skin_checked="1"></div> <div data-v-3a0f674e="" class="text" bis_skin_checked="1"><div data-v-3a0f674e="" class="text-back" bis_skin_checked="1">WHO WE ARE</div> <div data-v-3a0f674e="" class="text-half text--left" bis_skin_checked="1"><div data-v-3a0f674e="" class="inner" bis_skin_checked="1">WHO WE ARE</div></div> <div data-v-3a0f674e="" class="text-half text--right" bis_skin_checked="1"><div data-v-3a0f674e="" class="inner" bis_skin_checked="1">WHO WE ARE</div></div></div></div></div> <div data-v-4e6cd574="" class="bottom-t" bis_skin_checked="1"><div data-v-7c3efb1e="" data-v-4e6cd574="" class="e-title" bis_skin_checked="1" style="width: auto;"><h1 data-v-7c3efb1e=""><span data-v-7c3efb1e="" class="rect" style="animation-delay: 1.2s;"></span> <span data-v-7c3efb1e="" class="content" style="animation-delay: 1.2s;">BASED IN USA &amp; SINGAPORE, SINGAS EXCELS IN TRANSFORMING YOUR IDEAS, VISIONS, OR BUSINESS OBJECTIVES INTO CUTTING-EDGE WEB PRODUCTS AND DIGITAL SOLUTIONS.</span></h1></div></div></div></div></div> <div data-v-3e3229a0="" class="bottom-block" bis_skin_checked="1"><div data-v-21aaaca5="" data-v-3e3229a0="" class="social-media" bis_skin_checked="1"><div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://www.instagram.com/singasusa/" target="_blank" class="soc-mod-1">
      <img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_insta.svg" alt="" class="social-media-img"></a></div>
       <div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://www.facebook.com/SingasUSA/" target="_blank" class="soc-mod-2">
        <img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_facebook.svg" alt="" class="social-media-img"></a></div> 
        <div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://www.linkedin.com/company/singasusa/" target="blanck" class="soc-mod-3">
          <img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_in.svg" alt="" class="social-media-img"></a></div>
           <div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://twitter.com/singasusa" target="_blank" class="soc-mod-4">
            <img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_tw.svg" alt="" class="social-media-img twitter"></a></div>
          </div> <a data-v-b07ccaac="" data-v-3e3229a0="" href="/contact-us" class="email-btn"><svg data-v-b07ccaac="" xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="8.1138mm" height="8.1138mm" version="1.1" viewBox="0 0 811380 811380" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="shape-rendering: geometricprecision; text-rendering: geometricprecision; fill-rule: evenodd; clip-rule: evenodd;"><g data-v-b07ccaac=""><path data-v-b07ccaac="" fill="currentColor" d="M117700 100070l575990 0c30130,0 57530,12320 77350,32140 19820,19810 32140,47210 32140,77350l0 466270c0,24700 -11100,35480 -31140,35480 -19750,0 -38840,-23280 -61770,-51270 -24240,-29580 -54670,-66710 -65560,-66710l-527010 0c-30130,0 -57530,-12330 -77350,-32140 -19820,-19820 -32140,-47220 -32140,-77350l0 -274280c0,-30140 12320,-57540 32140,-77350 19820,-19820 47220,-32140 77350,-32140zm109710 209610l82290 0 0 82290 -82290 0 0 -82290zm274280 0l82290 0 0 82290 -82290 0 0 -82290zm-137140 0l82290 0 0 82290 -82290 0 0 -82290zm329140 -155190l-575990 0c-15100,0 -28870,6210 -38860,16200 -9990,9990 -16210,23770 -16210,38870l0 274280c0,15090 6220,28870 16210,38860 9990,9990 23760,16200 38860,16200l527010 0c35220,0 73170,44680 104050,82300l0 -411640c0,-15100 -6220,-28880 -16210,-38870 -9990,-9990 -23760,-16200 -38860,-16200z"></path></g></svg></a></div></div>
<div id='section3' class="section section3 section-template pr df fdc jcsb active" bis_skin_checked="1"><div class="plashka" bis_skin_checked="1"></div> <div class="scetch scetch2 scetch-mob" bis_skin_checked="1"><div data-v-4e6cd574="" class="wrapper" bis_skin_checked="1"><div data-v-4e6cd574="" class="letters-inner" bis_skin_checked="1"><!----></div> <div data-v-4e6cd574="" class="text-block" bis_skin_checked="1"><div data-v-4e6cd574="" class="top-text-wrapper" bis_skin_checked="1"><div data-v-3a0f674e="" data-v-4e6cd574="" class="top-text" bis_skin_checked="1"><div data-v-3a0f674e="" class="mobile-text active-text" bis_skin_checked="1"><div data-v-3a0f674e="" bis_skin_checked="1">
      WHAT WE DO
    </div></div> <div data-v-3a0f674e="" class="slash" bis_skin_checked="1"></div> <div data-v-3a0f674e="" class="text" bis_skin_checked="1"><div data-v-3a0f674e="" class="text-back" bis_skin_checked="1">WHAT WE DO</div> <div data-v-3a0f674e="" class="text-half text--left" bis_skin_checked="1"><div data-v-3a0f674e="" class="inner" bis_skin_checked="1">WHAT WE DO</div></div> <div data-v-3a0f674e="" class="text-half text--right" bis_skin_checked="1"><div data-v-3a0f674e="" class="inner" bis_skin_checked="1">WHAT WE DO</div></div></div></div></div> <div data-v-4e6cd574="" class="bottom-t" bis_skin_checked="1"><div data-v-7c3efb1e="" data-v-4e6cd574="" class="e-title" bis_skin_checked="1" style="width: auto;"><h1 data-v-7c3efb1e=""><span data-v-7c3efb1e="" class="rect" style="animation-delay: 1.2s;"></span> <span data-v-7c3efb1e="" class="content" style="animation-delay: 1.2s;">We develop various web systems, including but not limited to ERP, CRM, and GIS platforms.<br> Our team is adept in creating and implementing custom web products to support your  business growth.</span></h1></div></div></div></div></div> <div class="svg-img wwd" bis_skin_checked="1">
      <img src="<?php bloginfo('template_url'); ?>/assets/img/tech.svg" alt=""></div> <div class="abs100" bis_skin_checked="1"><div data-v-60fe5de0="" class="video-wrapper" bis_skin_checked="1"><!----> <video data-v-60fe5de0="" autoplay="autoplay" loop="loop" muted="muted" playsinline="" class="hideplay abs100 object-fit-cover z-index-1" style="opacity: 1;">
      <source data-v-60fe5de0="" src="<?php bloginfo('template_url'); ?>/assets/img/backsingas_VP8.webm">
      <source data-v-60fe5de0="" src="<?php bloginfo('template_url'); ?>/assets/img/backsingas.mp4"></video></div></div> <div class="top-block animate-text el1" bis_skin_checked="1"></div> <div data-v-c8fed6c8="" class="diagonal-animation-list" bis_skin_checked="1" style="color: rgb(121, 170, 249);"><div data-v-c8fed6c8="" class="diagonal-animation-item it-1" bis_skin_checked="1"><div data-v-c8fed6c8="" class="item-cube-1 cu-1" bis_skin_checked="1"><div data-v-c8fed6c8="" class="cu-11" bis_skin_checked="1"></div></div> <div data-v-c8fed6c8="" class="item-cube-2 cu-12" bis_skin_checked="1"></div></div> <div data-v-c8fed6c8="" class="diagonal-animation-item it-2" bis_skin_checked="1"><div data-v-c8fed6c8="" class="item-cube-1 cu-3" bis_skin_checked="1"><div data-v-c8fed6c8="" class="cu-31" bis_skin_checked="1"></div></div> <div data-v-c8fed6c8="" class="item-cube-1 cu-3-2" bis_skin_checked="1"><div data-v-c8fed6c8="" class="cu-91" bis_skin_checked="1"></div></div> <div data-v-c8fed6c8="" class="item-cube-2 cu-123" bis_skin_checked="1"></div></div> <div data-v-c8fed6c8="" class="diagonal-animation-item it-3" bis_skin_checked="1"><div data-v-c8fed6c8="" class="item-cube-1 cu-5" bis_skin_checked="1"><div data-v-c8fed6c8="" class="cu-51" bis_skin_checked="1"></div></div> <div data-v-c8fed6c8="" class="item-cube-1 cu-5-2" bis_skin_checked="1"><div data-v-c8fed6c8="" class="cu-61" bis_skin_checked="1"></div></div> <div data-v-c8fed6c8="" class="item-cube-2" bis_skin_checked="1"></div></div> <div data-v-c8fed6c8="" class="diagonal-animation-item it-4" bis_skin_checked="1"><div data-v-c8fed6c8="" class="item-cube-1 cu-7" bis_skin_checked="1"><div data-v-c8fed6c8="" class="cu-71" bis_skin_checked="1"></div></div> <div data-v-c8fed6c8="" class="item-cube-2" bis_skin_checked="1"></div></div> <div data-v-c8fed6c8="" class="diagonal-animation-item it-5" bis_skin_checked="1"><div data-v-c8fed6c8="" class="item-cube-2" bis_skin_checked="1"></div></div></div> <div data-v-3e3229a0="" class="bottom-block" bis_skin_checked="1"><div data-v-21aaaca5="" data-v-3e3229a0="" class="social-media" bis_skin_checked="1"><div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://www.instagram.com/singasusa/" target="_blank" class="soc-mod-1">
        <img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_insta.svg" alt="" class="social-media-img"></a></div> 
        <div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://www.facebook.com/SingasUSA/" target="_blank" class="soc-mod-2">
          <img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_facebook.svg" alt="" class="social-media-img"></a></div> 
          <div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://www.linkedin.com/company/singasusa/" target="blanck" class="soc-mod-3"><img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_in.svg" alt="" class="social-media-img"></a></div> <div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://twitter.com/singasusa" target="_blank" class="soc-mod-4"><img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_tw.svg" alt="" class="social-media-img twitter"></a></div></div> <a data-v-b07ccaac="" data-v-3e3229a0="" href="/contact-us" class="email-btn"><svg data-v-b07ccaac="" xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="8.1138mm" height="8.1138mm" version="1.1" viewBox="0 0 811380 811380" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="shape-rendering: geometricprecision; text-rendering: geometricprecision; fill-rule: evenodd; clip-rule: evenodd;"><g data-v-b07ccaac=""><path data-v-b07ccaac="" fill="currentColor" d="M117700 100070l575990 0c30130,0 57530,12320 77350,32140 19820,19810 32140,47210 32140,77350l0 466270c0,24700 -11100,35480 -31140,35480 -19750,0 -38840,-23280 -61770,-51270 -24240,-29580 -54670,-66710 -65560,-66710l-527010 0c-30130,0 -57530,-12330 -77350,-32140 -19820,-19820 -32140,-47220 -32140,-77350l0 -274280c0,-30140 12320,-57540 32140,-77350 19820,-19820 47220,-32140 77350,-32140zm109710 209610l82290 0 0 82290 -82290 0 0 -82290zm274280 0l82290 0 0 82290 -82290 0 0 -82290zm-137140 0l82290 0 0 82290 -82290 0 0 -82290zm329140 -155190l-575990 0c-15100,0 -28870,6210 -38860,16200 -9990,9990 -16210,23770 -16210,38870l0 274280c0,15090 6220,28870 16210,38860 9990,9990 23760,16200 38860,16200l527010 0c35220,0 73170,44680 104050,82300l0 -411640c0,-15100 -6220,-28880 -16210,-38870 -9990,-9990 -23760,-16200 -38860,-16200z"></path></g></svg></a></div></div>    
<div id='section4' class="section section5 section-template pr df fdc jcsb" bis_skin_checked="1">

<div class="scetch scetch2" bis_skin_checked="1"><div data-v-4e6cd574="" class="wrapper" bis_skin_checked="1"><div data-v-4e6cd574="" class="letters-inner" bis_skin_checked="1"><!----></div> <div data-v-4e6cd574="" class="text-block" bis_skin_checked="1"><div data-v-4e6cd574="" class="top-text-wrapper" bis_skin_checked="1"><div data-v-3a0f674e="" data-v-4e6cd574="" class="top-text" bis_skin_checked="1"><div data-v-3a0f674e="" class="mobile-text active-text" bis_skin_checked="1"><div data-v-3a0f674e="" bis_skin_checked="1">
      HOW WE DO IT
    </div></div> <div data-v-3a0f674e="" class="slash" bis_skin_checked="1"></div> <div data-v-3a0f674e="" class="text" bis_skin_checked="1"><div data-v-3a0f674e="" class="text-back" bis_skin_checked="1">HOW WE DO IT</div> <div data-v-3a0f674e="" class="text-half text--left" bis_skin_checked="1"><div data-v-3a0f674e="" class="inner" bis_skin_checked="1">HOW WE DO IT</div></div> <div data-v-3a0f674e="" class="text-half text--right" bis_skin_checked="1"><div data-v-3a0f674e="" class="inner" bis_skin_checked="1">HOW WE DO IT</div></div></div></div></div> <!----></div></div></div> <div class="text-i" bis_skin_checked="1"><span><p>Our solution engineers can assist you in selecting</p></span>
     <span><p>the most appropriate technologies for your upcoming project.</p></span>
  </div> <div data-v-25cd050a="" class="icons-grid" bis_skin_checked="1"><div data-v-25cd050a="" class="icon-col " bis_skin_checked="1"><div data-v-25cd050a="" class="icon-inner" bis_skin_checked="1"><div data-v-25cd050a="" class="icon" bis_skin_checked="1" style="animation-delay: 1s;"><img data-v-25cd050a="" src="<?php bloginfo('template_url'); ?>/assets/img/php.svg" alt="icon" class="icon-img abs-center"></div></div></div><div data-v-25cd050a="" class="icon-col " bis_skin_checked="1"><div data-v-25cd050a="" class="icon-inner" bis_skin_checked="1"><div data-v-25cd050a="" class="icon" bis_skin_checked="1" style="animation-delay: 1.1s;"><img data-v-25cd050a="" src="<?php bloginfo('template_url'); ?>/assets/img/laravel.svg" alt="icon" class="icon-img abs-center"></div></div></div><div data-v-25cd050a="" class="icon-col " bis_skin_checked="1"><div data-v-25cd050a="" class="icon-inner" bis_skin_checked="1"><div data-v-25cd050a="" class="icon" bis_skin_checked="1" style="animation-delay: 1.2s;"><img data-v-25cd050a="" src="<?php bloginfo('template_url'); ?>/assets/img/vjs.svg" alt="icon" class="icon-img abs-center"></div></div></div><div data-v-25cd050a="" class="icon-col " bis_skin_checked="1"><div data-v-25cd050a="" class="icon-inner" bis_skin_checked="1"><div data-v-25cd050a="" class="icon" bis_skin_checked="1" style="animation-delay: 1.3s;"><img data-v-25cd050a="" src="<?php bloginfo('template_url'); ?>/assets/img/apache.svg" alt="icon" class="icon-img abs-center"></div></div></div><div data-v-25cd050a="" class="icon-col " bis_skin_checked="1"><div data-v-25cd050a="" class="icon-inner" bis_skin_checked="1"><div data-v-25cd050a="" class="icon" bis_skin_checked="1" style="animation-delay: 1.4s;"><img data-v-25cd050a="" src="<?php bloginfo('template_url'); ?>/assets/img/angular.svg" alt="icon" class="icon-img abs-center"></div></div></div><div data-v-25cd050a="" class="icon-col " bis_skin_checked="1"><div data-v-25cd050a="" class="icon-inner" bis_skin_checked="1"><div data-v-25cd050a="" class="icon" bis_skin_checked="1" style="animation-delay: 1.5s;"><img data-v-25cd050a="" src="<?php bloginfo('template_url'); ?>/assets/img/elastic.svg" alt="icon" class="icon-img abs-center"></div></div></div><div data-v-25cd050a="" class="icon-col visible-desktop" bis_skin_checked="1"><div data-v-25cd050a="" class="icon-inner" bis_skin_checked="1"><div data-v-25cd050a="" class="icon" bis_skin_checked="1" style="animation-delay: 1.6s;"><img data-v-25cd050a="" src="<?php bloginfo('template_url'); ?>/assets/img/flowtensor.svg" alt="icon" class="icon-img abs-center"></div></div></div><div data-v-25cd050a="" class="icon-col visible-desktop" bis_skin_checked="1"><div data-v-25cd050a="" class="icon-inner" bis_skin_checked="1"><div data-v-25cd050a="" class="icon" bis_skin_checked="1" style="animation-delay: 1.7s;"><img data-v-25cd050a="" src="<?php bloginfo('template_url'); ?>/assets/img/go.svg" alt="icon" class="icon-img abs-center"></div></div></div><div data-v-25cd050a="" class="icon-col visible-desktop" bis_skin_checked="1"><div data-v-25cd050a="" class="icon-inner" bis_skin_checked="1"><div data-v-25cd050a="" class="icon" bis_skin_checked="1" style="animation-delay: 1.8s;"><img data-v-25cd050a="" src="<?php bloginfo('template_url'); ?>/assets/img/mongodb.svg" alt="icon" class="icon-img abs-center"></div></div></div><div data-v-25cd050a="" class="icon-col visible-desktop" bis_skin_checked="1"><div data-v-25cd050a="" class="icon-inner" bis_skin_checked="1"><div data-v-25cd050a="" class="icon" bis_skin_checked="1" style="animation-delay: 1.8s;"><img data-v-25cd050a="" src="<?php bloginfo('template_url'); ?>/assets/img/mysql.svg" alt="icon" class="icon-img abs-center"></div></div></div><div data-v-25cd050a="" class="icon-col visible-desktop" bis_skin_checked="1"><div data-v-25cd050a="" class="icon-inner" bis_skin_checked="1"><div data-v-25cd050a="" class="icon" bis_skin_checked="1" style="animation-delay: 1.7s;"><img data-v-25cd050a="" src="<?php bloginfo('template_url'); ?>/assets/img/nodejs.svg" alt="icon" class="icon-img abs-center"></div></div></div><div data-v-25cd050a="" class="icon-col visible-desktop" bis_skin_checked="1"><div data-v-25cd050a="" class="icon-inner" bis_skin_checked="1"><div data-v-25cd050a="" class="icon" bis_skin_checked="1" style="animation-delay: 1.6s;"><img data-v-25cd050a="" src="<?php bloginfo('template_url'); ?>/assets/img/psql.svg" alt="icon" class="icon-img abs-center"></div></div></div><div data-v-25cd050a="" class="icon-col visible-desktop" bis_skin_checked="1"><div data-v-25cd050a="" class="icon-inner" bis_skin_checked="1"><div data-v-25cd050a="" class="icon" bis_skin_checked="1" style="animation-delay: 1.5s;"><img data-v-25cd050a="" src="<?php bloginfo('template_url'); ?>/assets/img/react.svg" alt="icon" class="icon-img abs-center"></div></div></div><div data-v-25cd050a="" class="icon-col visible-desktop" bis_skin_checked="1"><div data-v-25cd050a="" class="icon-inner" bis_skin_checked="1"><div data-v-25cd050a="" class="icon" bis_skin_checked="1" style="animation-delay: 1.4s;"><img data-v-25cd050a="" src="<?php bloginfo('template_url'); ?>/assets/img/redis.svg" alt="icon" class="icon-img abs-center"></div></div></div><div data-v-25cd050a="" class="icon-col visible-desktop" bis_skin_checked="1"><div data-v-25cd050a="" class="icon-inner" bis_skin_checked="1"><div data-v-25cd050a="" class="icon" bis_skin_checked="1" style="animation-delay: 1.3s;"><img data-v-25cd050a="" src="<?php bloginfo('template_url'); ?>/assets/img/socket.svg" alt="icon" class="icon-img abs-center"></div></div></div><div data-v-25cd050a="" class="icon-col visible-desktop" bis_skin_checked="1"><div data-v-25cd050a="" class="icon-inner" bis_skin_checked="1"><div data-v-25cd050a="" class="icon" bis_skin_checked="1" style="animation-delay: 1.2s;"><img data-v-25cd050a="" src="<?php bloginfo('template_url'); ?>/assets/img/xamarin.svg" alt="icon" class="icon-img abs-center"></div></div></div><div data-v-25cd050a="" class="icon-col visible-desktop" bis_skin_checked="1"><div data-v-25cd050a="" class="icon-inner" bis_skin_checked="1"><div data-v-25cd050a="" class="icon" bis_skin_checked="1" style="animation-delay: 1.1s;"><img data-v-25cd050a="" src="<?php bloginfo('template_url'); ?>/assets/img/csharp.svg" alt="icon" class="icon-img abs-center"></div></div></div><div data-v-25cd050a="" class="icon-col visible-desktop" bis_skin_checked="1"><div data-v-25cd050a="" class="icon-inner" bis_skin_checked="1"><div data-v-25cd050a="" class="icon" bis_skin_checked="1" style="animation-delay: 1s;"><img data-v-25cd050a="" src="<?php bloginfo('template_url'); ?>/assets/img/amazon.svg" alt="icon" class="icon-img abs-center"></div></div></div></div> <div data-v-3e3229a0="" class="bottom-block" bis_skin_checked="1"><div data-v-21aaaca5="" data-v-3e3229a0="" class="social-media" bis_skin_checked="1"><div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://www.instagram.com/singasusa/" target="_blank" class="soc-mod-1">
      <img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_insta.svg" alt="" class="social-media-img"></a></div> <div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://www.facebook.com/SingasUSA/" target="_blank" class="soc-mod-2"><img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_facebook.svg" alt="" class="social-media-img"></a></div> <div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://www.linkedin.com/company/singasusa/" target="blanck" class="soc-mod-3"><img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_in.svg" alt="" class="social-media-img"></a></div> <div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://twitter.com/singasusa" target="_blank" class="soc-mod-4"><img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_tw.svg" alt="" class="social-media-img twitter"></a></div></div> <a data-v-b07ccaac="" data-v-3e3229a0="" href="/contact-us" class="email-btn"><svg data-v-b07ccaac="" xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="8.1138mm" height="8.1138mm" version="1.1" viewBox="0 0 811380 811380" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="shape-rendering: geometricprecision; text-rendering: geometricprecision; fill-rule: evenodd; clip-rule: evenodd;"><g data-v-b07ccaac=""><path data-v-b07ccaac="" fill="currentColor" d="M117700 100070l575990 0c30130,0 57530,12320 77350,32140 19820,19810 32140,47210 32140,77350l0 466270c0,24700 -11100,35480 -31140,35480 -19750,0 -38840,-23280 -61770,-51270 -24240,-29580 -54670,-66710 -65560,-66710l-527010 0c-30130,0 -57530,-12330 -77350,-32140 -19820,-19820 -32140,-47220 -32140,-77350l0 -274280c0,-30140 12320,-57540 32140,-77350 19820,-19820 47220,-32140 77350,-32140zm109710 209610l82290 0 0 82290 -82290 0 0 -82290zm274280 0l82290 0 0 82290 -82290 0 0 -82290zm-137140 0l82290 0 0 82290 -82290 0 0 -82290zm329140 -155190l-575990 0c-15100,0 -28870,6210 -38860,16200 -9990,9990 -16210,23770 -16210,38870l0 274280c0,15090 6220,28870 16210,38860 9990,9990 23760,16200 38860,16200l527010 0c35220,0 73170,44680 104050,82300l0 -411640c0,-15100 -6220,-28880 -16210,-38870 -9990,-9990 -23760,-16200 -38860,-16200z"></path></g></svg></a></div></div>   
<div id='section5' class="section section2 pr df fdc jcsb active" bis_skin_checked="1"><div class="abs100 video-background" bis_skin_checked="1"><div data-v-60fe5de0="" class="video-wrapper" bis_skin_checked="1"><!----> <video data-v-60fe5de0="" autoplay="autoplay" loop="loop" muted="muted" playsinline="" class="hideplay abs100 object-fit-cover z-index-1" style="opacity: 1;">
<source data-v-60fe5de0="" src="<?php bloginfo('template_url'); ?>/assets/img/singastech.webm">
<source data-v-60fe5de0="" src="<?php bloginfo('template_url'); ?>/assets/img/singastech.mp4"></video></div></div> <div class="scetch" bis_skin_checked="1"><div data-v-4e6cd574="" class="wrapper" bis_skin_checked="1"><div data-v-4e6cd574="" class="letters-inner" bis_skin_checked="1"><!----></div> <div data-v-4e6cd574="" class="text-block" bis_skin_checked="1"><div data-v-4e6cd574="" class="top-text-wrapper" bis_skin_checked="1"><div data-v-3a0f674e="" data-v-4e6cd574="" class="top-text" bis_skin_checked="1"><div data-v-3a0f674e="" class="mobile-text active-text" bis_skin_checked="1"><div data-v-3a0f674e="" bis_skin_checked="1">
      WHY SINGAS
    </div></div> <div data-v-3a0f674e="" class="slash" bis_skin_checked="1"></div> <div data-v-3a0f674e="" class="text" bis_skin_checked="1">
      <div data-v-3a0f674e="" class="text-back" bis_skin_checked="1">WHY  SINGAS</div> <div data-v-3a0f674e="" class="text-half text--left" bis_skin_checked="1">
        <div data-v-3a0f674e="" class="inner" bis_skin_checked="1">WHY  SINGAS</div></div>
         <div data-v-3a0f674e="" class="text-half text--right" bis_skin_checked="1"><div data-v-3a0f674e="" class="inner" bis_skin_checked="1">WHY  SINGAS</div></div></div></div></div>
          <!----></div></div></div> <div class="text-i text-i3" bis_skin_checked="1"><div class="ovh" bis_skin_checked="1">
            <p>Singas has always been above and beyond all tech trends. Our team is experienced in</p></div> <div class="ovh" bis_skin_checked="1">
              <p>the most major industry standards and has domain knowledge in:</p></div></div> <div data-v-a5c792e6="" bis_skin_checked="1">
                <div data-v-a5c792e6="" class="icons-list" bis_skin_checked="1"><div data-v-a5c792e6="" class="icon-item " bis_skin_checked="1">
                  <img data-v-a5c792e6="" src="<?php bloginfo('template_url'); ?>/assets/img/singasusa73.svg" alt="" class="icon-img" style="animation-delay: 2.5s;"> 
                  <div data-v-a5c792e6="" class="item-title" bis_skin_checked="1"><div data-v-a5c792e6="" class="ovh" bis_skin_checked="1">
                    <h3 data-v-a5c792e6="" style="animation-delay: 3.4s;">finances</h3></div></div></div><div data-v-a5c792e6="" class="icon-item " bis_skin_checked="1">
                      <img data-v-a5c792e6="" src="<?php bloginfo('template_url'); ?>/assets/img/singasusa75.svg" alt="" class="icon-img" style="animation-delay: 2.8s;">
                       <div data-v-a5c792e6="" class="item-title" bis_skin_checked="1"><div data-v-a5c792e6="" class="ovh" bis_skin_checked="1">
                        <h3 data-v-a5c792e6="" style="animation-delay: 3.7s;">iot</h3></div></div></div><div data-v-a5c792e6="" class="icon-item " bis_skin_checked="1">
                          <img data-v-a5c792e6="" src="<?php bloginfo('template_url'); ?>/assets/img/singasusa74.svg" alt="" class="icon-img" style="animation-delay: 3.1s;">
                           <div data-v-a5c792e6="" class="item-title" bis_skin_checked="1"><div data-v-a5c792e6="" class="ovh" bis_skin_checked="1">
                            <h3 data-v-a5c792e6="" style="animation-delay: 4s;">healthcare</h3></div></div></div><div data-v-a5c792e6="" class="icon-item visible-desktop" bis_skin_checked="1"><img data-v-a5c792e6="" src="<?php bloginfo('template_url'); ?>/assets/img/singasusa72.svg" alt="" class="icon-img" style="animation-delay: 3.4s;"> <div data-v-a5c792e6="" class="item-title" bis_skin_checked="1"><div data-v-a5c792e6="" class="ovh" bis_skin_checked="1"><h3 data-v-a5c792e6="" style="animation-delay: 4.3s;">education</h3></div></div></div><div data-v-a5c792e6="" class="icon-item visible-desktop" bis_skin_checked="1"><img data-v-a5c792e6="" src="<?php bloginfo('template_url'); ?>/assets/img/singasusa76.svg" alt="" class="icon-img" style="animation-delay: 3.7s;"> <div data-v-a5c792e6="" class="item-title" bis_skin_checked="1"><div data-v-a5c792e6="" class="ovh" bis_skin_checked="1"><h3 data-v-a5c792e6="" style="animation-delay: 4.6s;">entertainment</h3></div></div></div><div data-v-a5c792e6="" class="icon-item visible-desktop" bis_skin_checked="1"><img data-v-a5c792e6="" src="<?php bloginfo('template_url'); ?>/assets/img/singasusa77.svg" alt="" class="icon-img" style="animation-delay: 4s;"> <div data-v-a5c792e6="" class="item-title" bis_skin_checked="1"><div data-v-a5c792e6="" class="ovh" bis_skin_checked="1"><h3 data-v-a5c792e6="" style="animation-delay: 4.9s;">security</h3></div></div></div></div></div> <div data-v-3e3229a0="" class="bottom-block" bis_skin_checked="1"><div data-v-21aaaca5="" data-v-3e3229a0="" class="social-media" bis_skin_checked="1"><div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://www.instagram.com/singasusa/" target="_blank" class="soc-mod-1">
      <img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_insta.svg" alt="" class="social-media-img"></a></div>
       <div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://www.facebook.com/SingasUSA/" target="_blank" class="soc-mod-2">
      <img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_facebook.svg" alt="" class="social-media-img"></a></div>
      <div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://www.linkedin.com/company/singasusa/" target="blanck" class="soc-mod-3">
        <img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_in.svg" alt="" class="social-media-img"></a></div>
        <div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://twitter.com/singasusa" target="_blank" class="soc-mod-4">
          <img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_tw.svg" alt="" class="social-media-img twitter"></a></div></div>
          <a data-v-b07ccaac="" data-v-3e3229a0="" href="/contact-us" class="email-btn"><svg data-v-b07ccaac="" xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="8.1138mm" height="8.1138mm" version="1.1" viewBox="0 0 811380 811380" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="shape-rendering: geometricprecision; text-rendering: geometricprecision; fill-rule: evenodd; clip-rule: evenodd;"><g data-v-b07ccaac=""><path data-v-b07ccaac="" fill="currentColor" d="M117700 100070l575990 0c30130,0 57530,12320 77350,32140 19820,19810 32140,47210 32140,77350l0 466270c0,24700 -11100,35480 -31140,35480 -19750,0 -38840,-23280 -61770,-51270 -24240,-29580 -54670,-66710 -65560,-66710l-527010 0c-30130,0 -57530,-12330 -77350,-32140 -19820,-19820 -32140,-47220 -32140,-77350l0 -274280c0,-30140 12320,-57540 32140,-77350 19820,-19820 47220,-32140 77350,-32140zm109710 209610l82290 0 0 82290 -82290 0 0 -82290zm274280 0l82290 0 0 82290 -82290 0 0 -82290zm-137140 0l82290 0 0 82290 -82290 0 0 -82290zm329140 -155190l-575990 0c-15100,0 -28870,6210 -38860,16200 -9990,9990 -16210,23770 -16210,38870l0 274280c0,15090 6220,28870 16210,38860 9990,9990 23760,16200 38860,16200l527010 0c35220,0 73170,44680 104050,82300l0 -411640c0,-15100 -6220,-28880 -16210,-38870 -9990,-9990 -23760,-16200 -38860,-16200z"></path></g></svg></a></div></div> 
<div id='section6' class="section section2 section-template pr df fdc jcsb active" bis_skin_checked="1"><div data-v-d565b03a="" bis_skin_checked="1">
  <div data-v-d565b03a="" class="icons-list" bis_skin_checked="1"><div data-v-d565b03a="" class="icon-item delay1" bis_skin_checked="1">
    <div data-v-d565b03a="" class="ovh df jcc" bis_skin_checked="1">
<img data-v-d565b03a="" src="<?php bloginfo('template_url'); ?>/assets/img/ra_logo1.svg" alt="" class="icon-img"></div></div><div data-v-d565b03a="" class="icon-item delay2 from-top" bis_skin_checked="1"><div data-v-d565b03a="" class="ovh df jcc" bis_skin_checked="1"><img data-v-d565b03a="" src="<?php bloginfo('template_url'); ?>/assets/img/ra_logo2.svg" alt="" class="icon-img"></div></div><div data-v-d565b03a="" class="icon-item visible-desktop" bis_skin_checked="1"><div data-v-d565b03a="" class="ovh df jcc" bis_skin_checked="1"><img data-v-d565b03a="" src="<?php bloginfo('template_url'); ?>/assets/img/ra_logo3.svg" alt="" class="icon-img"></div></div><div data-v-d565b03a="" class="icon-item delay2 from-top" bis_skin_checked="1"><div data-v-d565b03a="" class="ovh df jcc" bis_skin_checked="1"><img data-v-d565b03a="" src="<?php bloginfo('template_url'); ?>/assets/img/ra_logo4.svg" alt="" class="icon-img"></div></div><div data-v-d565b03a="" class="icon-item delay1" bis_skin_checked="1">
  <div data-v-d565b03a="" class="ovh df jcc" bis_skin_checked="1">
    <img data-v-d565b03a="" src="<?php bloginfo('template_url'); ?>/assets/img/ra_logo5.svg" alt="" class="icon-img">
</div></div></div></div>
 <canvas id="binary-system2" class="binary-system"></canvas>
  <div class="scetch" bis_skin_checked="1"><div data-v-4e6cd574="" class="wrapper" bis_skin_checked="1"><div data-v-4e6cd574="" class="letters-inner" bis_skin_checked="1"><!----></div> <div data-v-4e6cd574="" class="text-block" bis_skin_checked="1"><div data-v-4e6cd574="" class="top-text-wrapper" bis_skin_checked="1"><div data-v-3a0f674e="" data-v-4e6cd574="" class="top-text" bis_skin_checked="1"><div data-v-3a0f674e="" class="mobile-text active-text" bis_skin_checked="1"><div data-v-3a0f674e="" bis_skin_checked="1">
      OUR CLIENTS
    </div></div> <div data-v-3a0f674e="" class="slash" bis_skin_checked="1"></div> <div data-v-3a0f674e="" class="text" bis_skin_checked="1"><div data-v-3a0f674e="" class="text-back" bis_skin_checked="1">OUR CLIENTS</div> <div data-v-3a0f674e="" class="text-half text--left" bis_skin_checked="1"><div data-v-3a0f674e="" class="inner" bis_skin_checked="1">OUR CLIENTS</div></div> <div data-v-3a0f674e="" class="text-half text--right" bis_skin_checked="1"><div data-v-3a0f674e="" class="inner" bis_skin_checked="1">OUR CLIENTS</div></div></div></div></div> <div data-v-4e6cd574="" class="bottom-t" bis_skin_checked="1"><div data-v-7c3efb1e="" data-v-4e6cd574="" class="e-title" bis_skin_checked="1" style="width: auto;"><h1 data-v-7c3efb1e=""><span data-v-7c3efb1e="" class="rect" style="animation-delay: 1.2s;"></span>
     <span data-v-7c3efb1e="" class="content" style="animation-delay: 1.2s;">We work with medium and large enterprises and focus on automating core business processes to maximize efficiency.</span>
  </h1></div></div></div></div></div> <div class="b-inner1 center-mobile" bis_skin_checked="1"><a data-v-636ea7e7="" href="/projects" class="btnn">more details</a></div> <div data-v-3e3229a0="" class="bottom-block" bis_skin_checked="1"><div data-v-21aaaca5="" data-v-3e3229a0="" class="social-media" bis_skin_checked="1"><div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://www.instagram.com/singasusa/" target="_blank" class="soc-mod-1">
      <img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_insta.svg" alt="" class="social-media-img"></a></div> <div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://www.facebook.com/SingasUSA/" target="_blank" class="soc-mod-2">
      <img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_facebook.svg" alt="" class="social-media-img"></a></div>
       <div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://www.linkedin.com/company/singasusa/" target="blanck" class="soc-mod-3">
        <img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_in.svg" alt="" class="social-media-img"></a></div>
         <div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://twitter.com/singasusa" target="_blank" class="soc-mod-4">
          <img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_tw.svg" alt="" class="social-media-img twitter"></a></div></div> <a data-v-b07ccaac="" data-v-3e3229a0="" href="/contact-us" class="email-btn"><svg data-v-b07ccaac="" xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="8.1138mm" height="8.1138mm" version="1.1" viewBox="0 0 811380 811380" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="shape-rendering: geometricprecision; text-rendering: geometricprecision; fill-rule: evenodd; clip-rule: evenodd;"><g data-v-b07ccaac=""><path data-v-b07ccaac="" fill="currentColor" d="M117700 100070l575990 0c30130,0 57530,12320 77350,32140 19820,19810 32140,47210 32140,77350l0 466270c0,24700 -11100,35480 -31140,35480 -19750,0 -38840,-23280 -61770,-51270 -24240,-29580 -54670,-66710 -65560,-66710l-527010 0c-30130,0 -57530,-12330 -77350,-32140 -19820,-19820 -32140,-47220 -32140,-77350l0 -274280c0,-30140 12320,-57540 32140,-77350 19820,-19820 47220,-32140 77350,-32140zm109710 209610l82290 0 0 82290 -82290 0 0 -82290zm274280 0l82290 0 0 82290 -82290 0 0 -82290zm-137140 0l82290 0 0 82290 -82290 0 0 -82290zm329140 -155190l-575990 0c-15100,0 -28870,6210 -38860,16200 -9990,9990 -16210,23770 -16210,38870l0 274280c0,15090 6220,28870 16210,38860 9990,9990 23760,16200 38860,16200l527010 0c35220,0 73170,44680 104050,82300l0 -411640c0,-15100 -6220,-28880 -16210,-38870 -9990,-9990 -23760,-16200 -38860,-16200z"></path></g></svg></a></div></div>   
           <div id='section7' class="section section5 section5a section-template pr df fdc jcsb active" bis_skin_checked="1"><!----> <div class="scetch" bis_skin_checked="1"><div data-v-4e6cd574="" class="wrapper" bis_skin_checked="1"><div data-v-4e6cd574="" class="letters-inner" bis_skin_checked="1"><!----></div> <div data-v-4e6cd574="" class="text-block" bis_skin_checked="1"><div data-v-4e6cd574="" class="top-text-wrapper" bis_skin_checked="1"><div data-v-3a0f674e="" data-v-4e6cd574="" class="top-text" bis_skin_checked="1"><div data-v-3a0f674e="" class="mobile-text active-text" bis_skin_checked="1"><div data-v-3a0f674e="" bis_skin_checked="1">
      OUR CORE TEAM
    </div></div> <div data-v-3a0f674e="" class="slash" bis_skin_checked="1"></div> <div data-v-3a0f674e="" class="text" bis_skin_checked="1"><div data-v-3a0f674e="" class="text-back" bis_skin_checked="1">OUR CORE TEAM</div> <div data-v-3a0f674e="" class="text-half text--left" bis_skin_checked="1"><div data-v-3a0f674e="" class="inner" bis_skin_checked="1">OUR CORE TEAM</div></div> <div data-v-3a0f674e="" class="text-half text--right" bis_skin_checked="1"><div data-v-3a0f674e="" class="inner" bis_skin_checked="1">OUR CORE TEAM</div></div></div></div></div> <!----></div></div></div> <div data-v-5daa1d2f="" class="boss-photo" bis_skin_checked="1"><div data-v-6b991e45="" data-v-5daa1d2f="" class="team-photo-anim size-large" bis_skin_checked="1"><div data-v-6b991e45="" to="/team/Berg" class="team-item-ovh " bis_skin_checked="1"><div data-v-6b991e45="" class="team-item" bis_skin_checked="1" style="animation-delay: 0.5s;"><div data-v-6b991e45="" class="img-inner" bis_skin_checked="1">
      <img data-v-6b991e45="" src="<?php bloginfo('template_url'); ?>/assets/img/berg.png" alt="" class="team-img"></div> <div data-v-6b991e45="" class="ovh" bis_skin_checked="1"><h3 data-v-6b991e45="" class="team-title" style="animation-delay: 1s;">Berg</h3></div> <div data-v-6b991e45="" class="ovh" bis_skin_checked="1"><h2 data-v-6b991e45="" class="team-title team-title2" style="animation-delay: 1.2s;">
          CTO SINGAS</h2></div></div></div><div data-v-6b991e45="" to="/team/Storm" class="team-item-ovh " bis_skin_checked="1"><div data-v-6b991e45="" class="team-item" bis_skin_checked="1" style="animation-delay: 0.6s;"><div data-v-6b991e45="" class="img-inner" bis_skin_checked="1"><img data-v-6b991e45="" src="<?php bloginfo('template_url'); ?>/assets/img/storm.png" alt="" class="team-img"></div> <div data-v-6b991e45="" class="ovh" bis_skin_checked="1"><h3 data-v-6b991e45="" class="team-title" style="animation-delay: 1.1s;">Storm</h3></div> <div data-v-6b991e45="" class="ovh" bis_skin_checked="1"><h2 data-v-6b991e45="" class="team-title team-title2" style="animation-delay: 1.3s;">
          CFO SINGAS</h2></div></div></div><div data-v-6b991e45="" to="/team/Yuliana" class="team-item-ovh " bis_skin_checked="1"><div data-v-6b991e45="" class="team-item" bis_skin_checked="1" style="animation-delay: 0.7s;"><div data-v-6b991e45="" class="img-inner" bis_skin_checked="1"><img data-v-6b991e45="" src="<?php bloginfo('template_url'); ?>/assets/img/yuliana.png" alt="" class="team-img"></div> <div data-v-6b991e45="" class="ovh" bis_skin_checked="1"><h3 data-v-6b991e45="" class="team-title" style="animation-delay: 1.2s;">Yuliana</h3></div> <div data-v-6b991e45="" class="ovh" bis_skin_checked="1"><h2 data-v-6b991e45="" class="team-title team-title2" style="animation-delay: 1.4s;">
          BUSINESS ANALYST</h2></div></div></div><div data-v-6b991e45="" to="/team/Alexander" class="team-item-ovh " bis_skin_checked="1"><div data-v-6b991e45="" class="team-item" bis_skin_checked="1" style="animation-delay: 0.8s;"><div data-v-6b991e45="" class="img-inner" bis_skin_checked="1"><img data-v-6b991e45="" src="<?php bloginfo('template_url'); ?>/assets/img/alex.png" alt="" class="team-img"></div> <div data-v-6b991e45="" class="ovh" bis_skin_checked="1"><h3 data-v-6b991e45="" class="team-title" style="animation-delay: 1.3s;">Alexander</h3></div> <div data-v-6b991e45="" class="ovh" bis_skin_checked="1"><h2 data-v-6b991e45="" class="team-title team-title2" style="animation-delay: 1.5s;">
          CEO USA</h2></div></div></div></div></div> <div data-v-f9b95b92="" class="team-inner visible-desktop" bis_skin_checked="1"><div data-v-6b991e45="" data-v-f9b95b92="" class="team-photo-anim size-small" bis_skin_checked="1"><div data-v-6b991e45="" to="/team/Kate" class="team-item-ovh " bis_skin_checked="1"><div data-v-6b991e45="" class="team-item" bis_skin_checked="1" style="animation-delay: 1.5s;"><div data-v-6b991e45="" class="img-inner" bis_skin_checked="1"><img data-v-6b991e45="" src="<?php bloginfo('template_url'); ?>/assets/img/kate.png" alt="" class="team-img"></div> <div data-v-6b991e45="" class="ovh" bis_skin_checked="1"><h3 data-v-6b991e45="" class="team-title" style="animation-delay: 2s;">Kate</h3></div> <div data-v-6b991e45="" class="ovh" bis_skin_checked="1"><h2 data-v-6b991e45="" class="team-title team-title2" style="animation-delay: 2.2s;">
          SENIOR QA / TEAM LEAD</h2></div></div></div><div data-v-6b991e45="" to="/team/Yury" class="team-item-ovh " bis_skin_checked="1"><div data-v-6b991e45="" class="team-item" bis_skin_checked="1" style="animation-delay: 1.6s;"><div data-v-6b991e45="" class="img-inner" bis_skin_checked="1"><img data-v-6b991e45="" src="<?php bloginfo('template_url'); ?>/assets/img/yury.png" alt="" class="team-img"></div> <div data-v-6b991e45="" class="ovh" bis_skin_checked="1"><h3 data-v-6b991e45="" class="team-title" style="animation-delay: 2.1s;">Yury</h3></div> <div data-v-6b991e45="" class="ovh" bis_skin_checked="1"><h2 data-v-6b991e45="" class="team-title team-title2" style="animation-delay: 2.3s;">
          senior frontend dev</h2></div></div></div><div data-v-6b991e45="" to="/team/Sergey" class="team-item-ovh " bis_skin_checked="1"><div data-v-6b991e45="" class="team-item" bis_skin_checked="1" style="animation-delay: 1.7s;"><div data-v-6b991e45="" class="img-inner" bis_skin_checked="1"><img data-v-6b991e45="" src="<?php bloginfo('template_url'); ?>/assets/img/sergey.png" alt="" class="team-img"></div> <div data-v-6b991e45="" class="ovh" bis_skin_checked="1"><h3 data-v-6b991e45="" class="team-title" style="animation-delay: 2.2s;">Sergey</h3></div> <div data-v-6b991e45="" class="ovh" bis_skin_checked="1"><h2 data-v-6b991e45="" class="team-title team-title2" style="animation-delay: 2.4s;">
          senior backend dev</h2></div></div></div><div data-v-6b991e45="" to="/team/Mario" class="team-item-ovh " bis_skin_checked="1"><div data-v-6b991e45="" class="team-item" bis_skin_checked="1" style="animation-delay: 1.8s;"><div data-v-6b991e45="" class="img-inner" bis_skin_checked="1"><img data-v-6b991e45="" src="<?php bloginfo('template_url'); ?>/assets/img/mario.png" alt="" class="team-img"></div> <div data-v-6b991e45="" class="ovh" bis_skin_checked="1"><h3 data-v-6b991e45="" class="team-title" style="animation-delay: 2.3s;">Mario</h3></div> <div data-v-6b991e45="" class="ovh" bis_skin_checked="1"><h2 data-v-6b991e45="" class="team-title team-title2" style="animation-delay: 2.5s;">
          senior devops</h2></div></div></div><div data-v-6b991e45="" to="/team/Daria" class="team-item-ovh " bis_skin_checked="1"><div data-v-6b991e45="" class="team-item" bis_skin_checked="1" style="animation-delay: 1.9s;"><div data-v-6b991e45="" class="img-inner" bis_skin_checked="1"><img data-v-6b991e45="" src="<?php bloginfo('template_url'); ?>/assets/img/daria.png" alt="" class="team-img"></div> <div data-v-6b991e45="" class="ovh" bis_skin_checked="1"><h3 data-v-6b991e45="" class="team-title" style="animation-delay: 2.4s;">Daria</h3></div> <div data-v-6b991e45="" class="ovh" bis_skin_checked="1"><h2 data-v-6b991e45="" class="team-title team-title2" style="animation-delay: 2.6s;">
          ui/ux designer</h2></div></div></div><div data-v-6b991e45="" to="/team/Mary" class="team-item-ovh " bis_skin_checked="1"><div data-v-6b991e45="" class="team-item" bis_skin_checked="1" style="animation-delay: 2s;"><div data-v-6b991e45="" class="img-inner" bis_skin_checked="1"><img data-v-6b991e45="" src="<?php bloginfo('template_url'); ?>/assets/img/mary.png" alt="" class="team-img"></div> <div data-v-6b991e45="" class="ovh" bis_skin_checked="1"><h3 data-v-6b991e45="" class="team-title" style="animation-delay: 2.5s;">Mary</h3></div> <div data-v-6b991e45="" class="ovh" bis_skin_checked="1"><h2 data-v-6b991e45="" class="team-title team-title2" style="animation-delay: 2.7s;">
          Content Creator</h2></div></div></div></div></div> <!----> <!----></div> 
<div id='section8' class="section section8 pr df fdc jcsb active" bis_skin_checked="1"><div data-v-60fe5de0="" class="video-wrapper" bis_skin_checked="1"><!----> <video data-v-60fe5de0="" autoplay="autoplay" loop="loop" muted="muted" playsinline="" class="hideplay abs100 object-fit-cover z-index-1" style="opacity: 1;">
<source data-v-60fe5de0="" src="<?php bloginfo('template_url'); ?>/assets/img/singascore.webm">
<source data-v-60fe5de0="" src="<?php bloginfo('template_url'); ?>/assets/img/singascore.mp4"></video></div> <div bis_skin_checked="1"></div> <div data-v-2922031b="" class="inner" bis_skin_checked="1"><div data-v-2922031b="" class="parentheses-l" bis_skin_checked="1">[</div> <p data-v-2922031b="" class="parentheses-text">
  Imagine combining the best values, people, and technology to transform web development.
</p> <div data-v-2922031b="" class="parentheses-r" bis_skin_checked="1">]</div></div> <div class="know-inner" bis_skin_checked="1"><div data-v-70a211d1="" bis_skin_checked="1"><div data-v-70a211d1="" class="word-inner" bis_skin_checked="1"><div data-v-70a211d1="" class="word11 wordd" bis_skin_checked="1">KNOWLEDGE</div> <p data-v-70a211d1="" class="wordd-text">Knowledge is a power. We facilitate our clients with every expert's proficiency
      possible.</p> <div data-v-70a211d1="" class="word-del12 word12 wordd" bis_skin_checked="1">SUCCESS</div> <p data-v-70a211d1="" class="wordd-text word-del12">Our success totally depends on 100% client satisfaction.</p> <div data-v-70a211d1="" class="word-del13 wordd" bis_skin_checked="1">TECHNOLOGY</div> <p data-v-70a211d1="" class="wordd-text word-del13">We provide modern technology-based digital &amp; web solutions.</p> <div data-v-70a211d1="" class="word-del14 word14 wordd" bis_skin_checked="1">EXPERTISE</div> <p data-v-70a211d1="" class="wordd-text word-del14">We will professionally take your brand to the next digital level.</p> <div data-v-70a211d1="" class="word-del15 wordd worddd" bis_skin_checked="1">CREATIVITY</div> <p data-v-70a211d1="" class="wordd-text word-del15">Every idea is essential. We value our employees &amp; stakeholders for new views or
      opinions.</p></div> <div data-v-70a211d1="" class="plashka3" bis_skin_checked="1"></div></div></div> <div data-v-3e3229a0="" class="bottom-block" bis_skin_checked="1"><div data-v-21aaaca5="" data-v-3e3229a0="" class="social-media" bis_skin_checked="1"><div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://www.instagram.com/singasusa/" target="_blank" class="soc-mod-1">
        <img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_insta.svg" alt="" class="social-media-img"></a></div> 
        <div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://www.facebook.com/SingasUSA/" target="_blank" class="soc-mod-2">
          <img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_facebook.svg" alt="" class="social-media-img"></a></div>
           <div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://www.linkedin.com/company/singasusa/" target="blanck" class="soc-mod-3">
            <img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_in.svg" alt="" class="social-media-img"></a></div>
             <div data-v-21aaaca5="" class="social-media-icon" bis_skin_checked="1"><a data-v-21aaaca5="" href="https://twitter.com/singasusa" target="_blank" class="soc-mod-4">
              <img data-v-21aaaca5="" src="<?php bloginfo('template_url'); ?>/assets/img/singas_social_tw.svg" alt="" class="social-media-img twitter"></a></div></div> <a data-v-b07ccaac="" data-v-3e3229a0="" href="/contact-us" class="email-btn"><svg data-v-b07ccaac="" xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="8.1138mm" height="8.1138mm" version="1.1" viewBox="0 0 811380 811380" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="shape-rendering: geometricprecision; text-rendering: geometricprecision; fill-rule: evenodd; clip-rule: evenodd;"><g data-v-b07ccaac=""><path data-v-b07ccaac="" fill="currentColor" d="M117700 100070l575990 0c30130,0 57530,12320 77350,32140 19820,19810 32140,47210 32140,77350l0 466270c0,24700 -11100,35480 -31140,35480 -19750,0 -38840,-23280 -61770,-51270 -24240,-29580 -54670,-66710 -65560,-66710l-527010 0c-30130,0 -57530,-12330 -77350,-32140 -19820,-19820 -32140,-47220 -32140,-77350l0 -274280c0,-30140 12320,-57540 32140,-77350 19820,-19820 47220,-32140 77350,-32140zm109710 209610l82290 0 0 82290 -82290 0 0 -82290zm274280 0l82290 0 0 82290 -82290 0 0 -82290zm-137140 0l82290 0 0 82290 -82290 0 0 -82290zm329140 -155190l-575990 0c-15100,0 -28870,6210 -38860,16200 -9990,9990 -16210,23770 -16210,38870l0 274280c0,15090 6220,28870 16210,38860 9990,9990 23760,16200 38860,16200l527010 0c35220,0 73170,44680 104050,82300l0 -411640c0,-15100 -6220,-28880 -16210,-38870 -9990,-9990 -23760,-16200 -38860,-16200z"></path></g></svg></a></div></div>      <div class="global-scroll" bis_skin_checked="1">
        <div class="scroll-indicator" bis_skin_checked="1" style=" transition-duration: 500ms;"></div></div></div> <!----> <!----> <!----></div></div></div>
      <!-- <script>window.__NUXT__={config:{_app:{basePath:"/",assetsPath:"/_nuxt/",cdnURL:null}}}</script> -->
  <!-- <script src="./Singas USA_files/ef7f0ae.js.Без названия"></script>
  <script src="./Singas USA_files/a26290f.js.Без названия"></script>
  <script src="./Singas USA_files/9ff7d8e.js.Без названия"></script> -->

<?php get_footer(); ?>