document.addEventListener('DOMContentLoaded', function () {
  var sections = document.querySelectorAll('.section')

  function setSectionHeightToScreen() {
    var screenHeight =
      window.innerHeight ||
      document.documentElement.clientHeight ||
      document.body.clientHeight

    sections.forEach(function (section) {
      section.style.height = screenHeight + 'px'
    })
  }

  // Вызываем функцию при загрузке страницы и при изменении размера окна
  setSectionHeightToScreen()
  window.addEventListener('resize', setSectionHeightToScreen)
})

// document.addEventListener('DOMContentLoaded', function () {
//   var container = document.querySelector('.fixed-container')
//   var scrollIndicator = document.querySelector('.scroll-indicator')

//   var scrollAmount =
//     window.innerHeight ||
//     document.documentElement.clientHeight ||
//     document.body.clientHeight // Измените значение в соответствии с вашими требованиями
//   var currentPosition = 0
//   var fifthOfScreen = scrollAmount / 8
//   var currentPositionScrollIndicator = 0

//   function handleWheel(event) {
//     if (event.deltaY > 0) {
//       currentPosition -= scrollAmount
//       currentPositionScrollIndicator =
//         currentPositionScrollIndicator + scrollAmount + fifthOfScreen
//     } else {
//       currentPosition += scrollAmount
//       currentPositionScrollIndicator =
//         currentPositionScrollIndicator - fifthOfScreen - scrollAmount
//     }

//     // Ограничиваем значение currentPosition в пределах минимального и максимального значения
//     currentPosition = Math.max(currentPosition, -7 * scrollAmount)
//     currentPosition = Math.min(currentPosition, 0)
//     currentPositionScrollIndicator = Math.min(
//       currentPositionScrollIndicator,
//       scrollAmount * 8 - fifthOfScreen
//     )

//     currentPositionScrollIndicator = Math.max(currentPositionScrollIndicator, 0)

//     container.style.transform =
//       'translate3d(0px, ' + currentPosition + 'px, 0px)'
//     scrollIndicator.style.height = fifthOfScreen + 'px'
//     scrollIndicator.style.transform =
//       'translate3d(0px, ' + currentPositionScrollIndicator + 'px, 0px)'
//   }

//   // Добавляем обработчик события для колесика мыши
//   container.addEventListener('wheel', handleWheel)
// })

document.addEventListener('DOMContentLoaded', function () {
  var container = document.querySelector('.fixed-container')
  var scrollIndicator = document.querySelector('.scroll-indicator')

  var scrollAmount =
    window.innerHeight ||
    document.documentElement.clientHeight ||
    document.body.clientHeight // Измените значение в соответствии с вашими требованиями
  var currentPosition = 0
  var fifthOfScreen = scrollAmount / 8
  var currentPositionScrollIndicator = 0

  var isDragging = false
  var startY, startTop

  function handleWheel(event) {
    if (isDragging) {
      return
    }

    if (event.deltaY > 0) {
      currentPosition -= scrollAmount
      currentPositionScrollIndicator =
        currentPositionScrollIndicator + scrollAmount + fifthOfScreen
    } else {
      currentPosition += scrollAmount
      currentPositionScrollIndicator =
        currentPositionScrollIndicator - fifthOfScreen - scrollAmount
    }

    currentPosition = Math.max(currentPosition, -7 * scrollAmount)
    currentPosition = Math.min(currentPosition, 0)
    currentPositionScrollIndicator = Math.min(
      currentPositionScrollIndicator,
      scrollAmount * 8 - fifthOfScreen
    )

    currentPositionScrollIndicator = Math.max(currentPositionScrollIndicator, 0)

    container.style.transform =
      'translate3d(0px, ' + currentPosition + 'px, 0px)'
    scrollIndicator.style.height = fifthOfScreen + 'px'
    scrollIndicator.style.transform =
      'translate3d(0px, ' + currentPositionScrollIndicator + 'px, 0px)'
    scrollIndicator.setAttribute('scroll', currentPositionScrollIndicator)
  }

  function handleMouseDown(event) {
    isDragging = true
    startY = event.clientY
    startTop = currentPositionScrollIndicator
  }

  function handleMouseMove(event) {
    if (!isDragging) {
      return
    }

    var deltaY = event.clientY - startY
    currentPositionScrollIndicator = Math.max(
      Math.min(startTop + deltaY, scrollAmount * 8 - fifthOfScreen),
      0
    )

    container.style.transform =
      'translate3d(0px, ' +
      -((currentPositionScrollIndicator / scrollAmount) * 7 * scrollAmount) +
      'px, 0px)'
    scrollIndicator.style.transform =
      'translate3d(0px, ' + currentPositionScrollIndicator + 'px, 0px)'
  }

  function handleMouseUp() {
    isDragging = false
  }

  container.addEventListener('wheel', handleWheel)
  scrollIndicator.addEventListener('mousedown', handleMouseDown)
  // document.addEventListener('mousemove', handleMouseMove)
  document.addEventListener('mouseup', handleMouseUp)
})

document.addEventListener('DOMContentLoaded', function () {
  var menuBtn = document.querySelector('.menu-btn')
  var fixedBg = document.querySelector('.fixed-bg')
  var menu = document.querySelector('.menu')

  var isMenuActive = false

  menuBtn.addEventListener('click', function () {
    // Переключение состояния меню
    isMenuActive = !isMenuActive

    // Добавление или удаление классов и стилей в зависимости от состояния меню
    if (isMenuActive) {
      menuBtn.classList.add('active', 'pen')
      setTimeout(function () {
        menuBtn.classList.remove('pen')
      }, 3000)

      fixedBg.classList.add('active')
      menu.classList.add('active')
      menu.style.zIndex = '2'
    } else {
      menuBtn.classList.remove('active', 'pen')

      fixedBg.classList.remove('active')
      menu.classList.remove('active')
      menu.style.zIndex = ''
    }
  })
})

document.addEventListener('DOMContentLoaded', function () {
  var sections = document.querySelectorAll('.section') // Замените '.section' на ваш селектор для выбора секций

  function isElementInViewport(el) {
    var rect = el.getBoundingClientRect()
    return rect.top < 0 && rect.bottom >= 0
  }

  function getVisibleSection() {
    for (var i = 0; i < sections.length; i++) {
      if (isElementInViewport(sections[i])) {
        return sections[i].id
      }
    }
    return null // Если ни одна из секций не видна
  }

  // Обновлять текущую видимую секцию при прокрутке
  document.addEventListener('wheel', function (e) {
    var scrollIndicator = document.querySelector('.scroll-indicator')
    var scroll = scrollIndicator.getAttribute('scroll')
    var scrollAmount =
      window.innerHeight ||
      document.documentElement.clientHeight ||
      document.body.clientHeight
    var sections = document.querySelectorAll('.section')

    for (var i = 0; i < sections.length; i++) {
      sections[i].style.display = 'block'
    }

    var a = null
    if (scroll * 2 - (scrollAmount / 8) * 2 === scrollAmount * 2) {
      a = 1
    }
    if (scroll - (scrollAmount / 8) * 2 + scrollAmount === scrollAmount * 3) {
      a = 2
    }
    if (scroll - (scrollAmount / 8) * 3 + scrollAmount === scrollAmount * 4) {
      a = 3
    }
    if (scroll - (scrollAmount / 8) * 4 + scrollAmount === scrollAmount * 5) {
      a = 4
    }
    if (scroll - (scrollAmount / 8) * 5 + scrollAmount === scrollAmount * 6) {
      a = 5
    }
    if (scroll - (scrollAmount / 8) * 6 + scrollAmount === scrollAmount * 7) {
      a = 6
    }
    if (scroll - (scrollAmount / 8) * 7 + scrollAmount === scrollAmount * 7) {
      a = 7
    }

    sections[a].style.display = 'block'
    for (var i = 0; i < sections.length; i++) {
      if (a === i) {
        console.log(a)
        console.log(i)
        var b = i - 1
        var c = i + 1
        sections[b].style.display = 'none'
        sections[c].style.display = 'none'
      }
    }
  })

  // Обновить текущую видимую секцию при загрузке страницы
  var initialVisibleSection = getVisibleSection()
  if (initialVisibleSection) {
    console.log('Текущая видимая секция:', initialVisibleSection)
  }
})
